For installation instructions and examples check out https://avioli.github.io/jquery-lightbox/ - the project page.

Join the chat at https://gitter.im/avioli/jquery-lightbox but keep in mind I don't hang there all the time. You'll be better off creating a new issue.
